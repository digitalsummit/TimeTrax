﻿namespace System.Data.Entity.Utilities
{
    internal class ExcelExport
    {
    }
}