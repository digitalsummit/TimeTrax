﻿using System.Web.UI;

namespace TimeTrax.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}